// ── Constants ─────────────────────────────────────────────────────────────────
let _focusedId  = null;
let _focusedPos = null;
let _renderTimer = null;

function scheduleRender() {
  clearTimeout(_renderTimer);
  _renderTimer = setTimeout(() => {
    const activeEl = document.activeElement;
    if (activeEl && activeEl.id) {
      _focusedId  = activeEl.id;
      _focusedPos = activeEl.selectionStart ?? null;
    }
    render();
  }, 0);
}

const LANGUAGES = ['English','French','Spanish','German','Italian','Portuguese','Japanese','Korean','Mandarin','Cantonese','Russian','Arabic','Hindi','Dutch','Swedish','Norwegian','Danish','Finnish','Polish','Czech','Hungarian','Romanian','Turkish','Greek','Hebrew','Thai','Vietnamese','Indonesian','Malay'];
const AUDIO_FORMATS  = ['DTS-HD Master Audio','Dolby TrueHD','PCM 5.1','PCM 7.1','Dolby Digital 5.1','DTS 5.1','LPCM Stereo'];
const SUBTITLE_FMTS  = ['SRT','ASS','SSA','SUB','VTT','PGS (Blu-ray Native)'];
const VIDEO_FMTS     = ['H.264 AVC','H.265 HEVC','VC-1','MPEG-2'];
const RESOLUTIONS    = ['1080p (1920×1080)','720p (1280×720)','480p (720×480)','480p (720×576) PAL'];
const EXTRAS_TYPES   = ['Behind the Scenes','Deleted Scenes','Interviews','Trailers','Featurette','Short Film','Other'];

const VIDEO_QUALITY_MODES = [
  { id: 'crf18', label: 'High Quality', crf: 18, mult: 0.75 },
  { id: 'crf20', label: 'Balanced',     crf: 20, mult: 0.55 },
  { id: 'crf23', label: 'Compact',      crf: 23, mult: 0.40 },
];

const BD_COMPLIANT_RES = [[1920,1080],[1280,720],[720,480],[720,576]];
function getBdTargetRes(w, h) {
  if (BD_COMPLIANT_RES.some(([bw,bh]) => bw===w && bh===h)) return null;
  if (h >= 464 && h <= 496 && w <= 720) return { w:720,  h:480,  padOnly:true  };
  if (h >= 560 && h <= 592 && w <= 720) return { w:720,  h:576,  padOnly:true  };
  if (h >= 700 && h <= 760)             return { w:1280, h:720,  padOnly:false };
  if (h >= 900 && h <= 1100)            return { w:1920, h:1080, padOnly:false };
  return { w:1920, h:1080, padOnly:false };
}
function videoQualityMult(q) {
  const m = VIDEO_QUALITY_MODES.find(x => x.id === q);
  return m ? m.mult : 1.0;
}

// ── State ─────────────────────────────────────────────────────────────────────
let state = {
  // New UI state
  droppedFiles: [],        // { id, name, path, size, probeData, probing, assignedType, autoType }
  settingsPanelOpen: false,
  discType: 'auto',        // 'auto' | 'movie' | 'episodes' | 'multi-title'
  globalQuality: 'crf20',  // applied to all titles
  fastEncode: false,

  lightMode: false,
  systemFonts: [],
  tools: { ffmpeg:{found:false}, ffprobe:{found:false}, tsmuxer:{found:false}, mkvmerge:{found:false}, xorriso:{found:false}, makemkv:{found:false} },
  building: false, buildSteps: [], buildCurrentStep: -1,
  buildDone: false, buildError: null, builtIsoPath: null, ffmpegLog: '',
  buildEndTime: null, stepStartTimes: {}, stepDetails: {},
  crfTotalSecs: 0,
  probeCache: {},
  project: {
    title: '', description: '', discLabel: '',
    resolution: RESOLUTIONS[0], videoFormat: VIDEO_FMTS[0], outputDir: '',
    mainVideo: null,
    titles: [],
    discSize: 'BD-25',
    combinedEpisodes: null,
    audioTracks: [], subtitleTracks: [], chapters: [], extras: [],
    menuConfig: {
      theme: 'Cinematic Dark', title: '', subtitle: '',
      primaryColor: '#dbb85a', accentColor: '#c0392b', fontStyle: 'Helvetica Neue',
      titleSize: 'large', titleAlign: 'center',
      buttonStyle: 'outline', buttonLayout: 'horizontal',
      overlayOpacity: 50, showTitle: true, showChapterMenu: true, showLanguageMenu: true,
      backgroundImage: null, backgroundVideo: null,
      customPlayText: 'PLAY', customChaptersText: 'CHAPTERS', customAudioText: 'AUDIO',
      textStroke: false, textStrokeColor: '#000000', textStrokeWidth: 2,
      showButtonEmojis: true, logoImage: null,
      gradientEnabled: false, gradientColor1: '#080810', gradientColor2: '#1a1440', gradientDir: 'vertical',
      bgBlur: 0, bgBrightness: 100, bgContrast: 100,
      titleFontSize: 48, episodeFontSize: 13, fontWeight: 'bold', letterSpacing: 0,
      textShadow: false, textShadowColor: '#000000', textShadowBlur: 4,
      textShadowOffsetX: 2, textShadowOffsetY: 2, textColorOpacity: 100,
      btnBorderRadius: 4, btnBorderColor: '#dbb85a', btnBorderWidth: 1,
      hoverEffect: 'highlight', episodeSpacing: 8, showEpisodeNumbers: true,
      discTitleOverlay: false, discTitleText: '', discTitleFontSize: 28,
      discTitleColor: '#dbb85a', discTitlePosition: 'top-center',
      animatedBg: false, animationType: 'pan',
    },
  },
  form: {
    audio:    { lang:LANGUAGES[0], fmt:AUDIO_FORMATS[0], label:'', isDefault:false, file:null },
    subtitle: { lang:LANGUAGES[0], fmt:SUBTITLE_FMTS[0], isForced:false, isSDH:false, description:'', file:null },
    chapter:  { name:'', time:'00:00:00', thumb:null },
    extras:   { name:'', type:EXTRAS_TYPES[0], file:null },
  },
  probeData: null,
  mkv: { file:null, probing:false, probeData:null, tracks:[], imported:false },
  embeddedTracks: [],
  titleCompatibility: {},
  burning: false, burnStatus: null, burnMessage: '', burnDone: false, burnError: null,
  burnDriveInfo: null, burnPercent: null,
  showAbout: false,
};

function uid()      { return Math.random().toString(36).slice(2,9); }
function setState(p){ Object.assign(state, p); render(); }
function setPrj(p)  { setState({ project: { ...state.project, ...p } }); }
function setPrjText(p) {
  const activeEl = document.activeElement;
  if (activeEl && activeEl.id) { _focusedId = activeEl.id; _focusedPos = activeEl.selectionStart ?? null; }
  Object.assign(state, { project: { ...state.project, ...p } });
  render();
}
function setForm(t,p){ setState({ form: { ...state.form, [t]: { ...state.form[t], ...p } } }); }
function setMenu(p) { setPrj({ menuConfig: { ...state.project.menuConfig, ...p } }); }
function esc(s)     { return s ? String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') : ''; }

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  const tools    = await window.discForge.checkTools();
  const homeDir  = await window.discForge.getHomeDir();
  const outputDir = homeDir + '/Desktop';
  setState({ tools, project: { ...state.project, outputDir } });

  const missing = [];
  if (!tools.ffmpeg?.found)   missing.push({ name: 'ffmpeg',   install: tools.ffmpeg?.install   || 'brew install ffmpeg' });
  if (!tools.tsmuxer?.found)  missing.push({ name: 'tsMuxeR',  install: tools.tsmuxer?.install  || 'brew install --cask tsmuxer' });
  if (!tools.mkvmerge?.found) missing.push({ name: 'mkvmerge', install: tools.mkvmerge?.install || 'brew install mkvtoolnix' });
  if (missing.length > 0) {
    const msg = missing.map(m => `Missing: ${m.name}\n  Install with: ${m.install}`).join('\n\n');
    alert('Disc Forge — required tools not found:\n\n' + msg + '\n\nRestart the app after installing.');
  }

  try {
    if (window.queryLocalFonts) {
      const fonts = await window.queryLocalFonts();
      state.systemFonts = [...new Set(fonts.map(f => f.family))].sort();
    }
  } catch(_) { state.systemFonts = []; }

  window.discForge.onBuildProgress(handleBuildProgress);
  window.discForge.onFFmpegProgress(line => {
    if (line.startsWith('__CRF_START:')) { state.crfTotalSecs = parseFloat(line.slice(12)) || 0; return; }
    const timeMatch  = line.match(/time=(\d{2}):(\d{2}):([\d.]+)/);
    const speedMatch = line.match(/speed=\s*([\d.]+)x/);
    const fpsMatch   = line.match(/fps=\s*([\d.]+)/);
    const frameMatch = line.match(/frame=\s*(\d+)/);
    if (state.crfTotalSecs > 0 && timeMatch) {
      const currentSecs = parseInt(timeMatch[1])*3600 + parseInt(timeMatch[2])*60 + parseFloat(timeMatch[3]);
      const speed = speedMatch ? parseFloat(speedMatch[1]) : 0;
      const fps   = fpsMatch   ? parseFloat(fpsMatch[1])   : 0;
      const frame = frameMatch ? parseInt(frameMatch[1])    : 0;
      let etaStr = '';
      if (speed > 0.01 && state.crfTotalSecs > currentSecs) {
        const remSecs = Math.round((state.crfTotalSecs - currentSecs) / speed);
        if (remSecs > 3) etaStr = ' — ~' + Math.floor(remSecs/60) + 'm ' + (remSecs%60) + 's left';
      }
      const pct = Math.min(100, (currentSecs/state.crfTotalSecs*100)).toFixed(0);
      state.ffmpegLog = `CRF encode ${pct}%` + (fps > 0 ? ` · ${fps.toFixed(0)} fps` : '') + (frame > 0 ? ` · frame ${frame}` : '') + etaStr;
    } else {
      if (!timeMatch) state.crfTotalSecs = 0;
      state.ffmpegLog = line;
    }
    const el = document.getElementById('ffmpeg-log');
    if (el) el.textContent = state.ffmpegLog;
    appendLog(line);
  });

  document.body.classList.toggle('light-mode', state.lightMode);
}

// ── File pickers ──────────────────────────────────────────────────────────────
async function pickFile(filters) {
  const r = await window.discForge.openFileDialog({ filters });
  if (!r) return null;
  if (typeof r === 'string') return { path: r, name: r.split('/').pop(), size: 0 };
  return r;
}

async function pickOutputDir() {
  const d = await window.discForge.openFolderDialog();
  if (d) setPrj({ outputDir: d });
}

// ── Embedded tracks ───────────────────────────────────────────────────────────
function addEmbeddedTracksFromProbe(filePath, fileName, probeData) {
  const streams = probeData.streams || [];
  const existing = state.embeddedTracks || [];
  const detected = streams
    .filter(s => s.codec_type === 'audio' || s.codec_type === 'subtitle')
    .filter(s => !existing.some(t => t.sourceFile === filePath && t.streamIndex === s.index))
    .map(s => {
      const lang = (s.tags?.language || s.tags?.LANGUAGE || 'und').toLowerCase();
      const langMap = {eng:'English',fre:'French',fra:'French',spa:'Spanish',deu:'German',ger:'German',
        ita:'Italian',por:'Portuguese',jpn:'Japanese',kor:'Korean',zho:'Mandarin',chi:'Mandarin',
        rus:'Russian',ara:'Arabic',hin:'Hindi',nld:'Dutch',swe:'Swedish',nor:'Norwegian',
        dan:'Danish',fin:'Finnish',pol:'Polish',ces:'Czech',hun:'Hungarian',ron:'Romanian',
        tur:'Turkish',ell:'Greek',heb:'Hebrew',tha:'Thai',vie:'Vietnamese',ind:'Indonesian',msa:'Malay'};
      const language = langMap[lang] || 'English';
      const codec = s.codec_name || '';
      const fmtMap = {'dts':'DTS-HD Master Audio','truehd':'Dolby TrueHD','ac3':'Dolby Digital 5.1',
        'eac3':'Dolby Digital 5.1','aac':'Dolby Digital 5.1','flac':'PCM 5.1','pcm_s24le':'PCM 5.1',
        'pcm_s16le':'LPCM Stereo','subrip':'SRT','srt':'SRT','ass':'ASS','pgs':'PGS (Blu-ray Native)',
        'hdmv_pgs_subtitle':'PGS (Blu-ray Native)','vtt':'VTT','dvd_subtitle':'SRT'};
      const format = fmtMap[codec] || (s.codec_type === 'audio' ? 'DTS-HD Master Audio' : 'SRT');
      const title = s.tags?.title || s.tags?.TITLE || '';
      const isDefault = s.disposition?.default === 1;
      const isForced  = s.disposition?.forced  === 1;
      const isSDH = title.toLowerCase().includes('sdh') || title.toLowerCase().includes('cc');
      return {
        id: uid(), sourceFile: filePath, sourceFileName: fileName,
        streamIndex: s.index, codec, role: s.codec_type,
        language, format, label: title || language,
        description: title || '', isDefault, isForced, isSDH,
        included: true, trackIndex: s.index,
      };
    });
  if (detected.length > 0) state.embeddedTracks = [...(state.embeddedTracks || []), ...detected];
}

// ── Drop zone file handling ───────────────────────────────────────────────────
async function handleDroppedFiles(files) {
  if (!files || !files.length) return;
  const existingPaths = state.droppedFiles.map(f => f.path);
  const newFiles = files.filter(f => {
    const p = typeof f === 'string' ? f : (f.path || '');
    return p && !existingPaths.includes(p);
  }).map(f => {
    const path = typeof f === 'string' ? f : (f.path || f);
    const name = typeof f === 'string' ? f.split('/').pop() : (f.name || String(f).split('/').pop());
    const size = typeof f === 'object' ? (f.size || 0) : 0;
    return { id: uid(), name, path, size, probeData: null, probing: true, assignedType: 'auto', autoType: null };
  });
  if (!newFiles.length) return;

  state.droppedFiles = [...state.droppedFiles, ...newFiles];
  render();

  for (const f of newFiles) {
    try {
      const result = await window.discForge.probeFile(f.path);
      if (result.success && result.data) {
        cacheProbeData(f.path, result.data);
        addEmbeddedTracksFromProbe(f.path, f.name, result.data);
        state.droppedFiles = state.droppedFiles.map(df =>
          df.id === f.id ? { ...df, probing: false, probeData: result.data } : df
        );
      } else {
        state.droppedFiles = state.droppedFiles.map(df =>
          df.id === f.id ? { ...df, probing: false } : df
        );
      }
    } catch(_) {
      state.droppedFiles = state.droppedFiles.map(df =>
        df.id === f.id ? { ...df, probing: false } : df
      );
    }
    render();
  }

  autoClassifyDroppedFiles();

  // Auto-populate disc title from folder name of first file
  if (!state.project.title && state.droppedFiles.length > 0) {
    const firstPath = state.droppedFiles[0].path;
    const parts = firstPath.split('/');
    const folderName = parts.length >= 2 ? parts[parts.length - 2] : '';
    if (folderName && folderName !== '/' && !/^[A-Z]:/.test(folderName)) {
      setPrjText({ title: folderName.replace(/[._-]+/g, ' ').trim() });
      return; // setPrjText already calls render()
    }
  }
  render();
}

function autoClassifyDroppedFiles() {
  const files = state.droppedFiles;
  const probed = files.filter(f => f.probeData && !f.probing);
  if (probed.length === 0) return;

  if (probed.length === 1) {
    state.droppedFiles = files.map(f => ({ ...f, autoType: 'Movie' }));
    return;
  }

  const durations = probed.map(f => parseFloat(f.probeData.format?.duration || 0)).filter(d => d > 0);
  if (!durations.length) {
    state.droppedFiles = files.map(f => ({ ...f, autoType: 'Movie' }));
    return;
  }

  const sorted = [...durations].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];

  state.droppedFiles = files.map(f => {
    if (!f.probeData) return { ...f, autoType: 'Bonus Feature' };
    const dur = parseFloat(f.probeData.format?.duration || 0);
    if (!dur) return { ...f, autoType: 'Bonus Feature' };
    return { ...f, autoType: (dur / median) < 0.3 ? 'Bonus Feature' : 'Episode' };
  });
}

function resolvedFileType(f) {
  if (f.assignedType && f.assignedType !== 'auto') return f.assignedType;
  return f.autoType || 'Movie';
}

function detectedDiscType() {
  const active = state.droppedFiles.filter(f => resolvedFileType(f) !== 'Skip');
  if (active.length <= 1) return 'movie';
  const eps = active.filter(f => resolvedFileType(f) === 'Episode');
  return eps.length >= 1 ? 'episodes' : 'movie';
}

function effectiveDiscType() {
  return state.discType === 'auto' ? detectedDiscType() : state.discType;
}

// ── MKV track helpers (kept for build compatibility) ──────────────────────────
function streamLang(s) {
  const code = s.tags?.language||'und';
  return {eng:'English',fra:'French',fre:'French',spa:'Spanish',deu:'German',ger:'German',ita:'Italian',
    por:'Portuguese',jpn:'Japanese',kor:'Korean',zho:'Mandarin',chi:'Mandarin',rus:'Russian',ara:'Arabic',
    hin:'Hindi',nld:'Dutch',swe:'Swedish',nor:'Norwegian',dan:'Danish',fin:'Finnish',pol:'Polish',ces:'Czech',
    hun:'Hungarian',ron:'Romanian',tur:'Turkish',ell:'Greek',heb:'Hebrew',tha:'Thai',vie:'Vietnamese',
    ind:'Indonesian',msa:'Malay',und:'Unknown'}[code]||code;
}
function secToTc(sec) { const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=Math.floor(sec%60); return [h,m,s].map(v=>String(v).padStart(2,'0')).join(':'); }
function guessBDVideo(c) { return {h264:'H.264 AVC',hevc:'H.265 HEVC',vc1:'VC-1',mpeg2video:'MPEG-2'}[c]||'H.264 AVC'; }
function guessBDAudio(c) { return {dts:'DTS-HD Master Audio',truehd:'Dolby TrueHD',ac3:'Dolby Digital 5.1',eac3:'Dolby Digital 5.1',flac:'PCM 5.1',pcm_s16le:'LPCM Stereo',pcm_s24le:'PCM 5.1',aac:'Dolby Digital 5.1'}[c]||'Dolby Digital 5.1'; }
function guessBDSub(c)   { return {hdmv_pgs_subtitle:'PGS (Blu-ray Native)',subrip:'SRT',ass:'ASS',ssa:'SSA',dvd_subtitle:'SUB'}[c]||'SRT'; }

const rmAudio    = id => setPrj({ audioTracks:    state.project.audioTracks.filter(t=>t.id!==id) });
const rmSubtitle = id => setPrj({ subtitleTracks: state.project.subtitleTracks.filter(t=>t.id!==id) });
const rmChapter  = id => setPrj({ chapters:       state.project.chapters.filter(t=>t.id!==id) });
const rmExtra    = id => setPrj({ extras:         state.project.extras.filter(t=>t.id!==id) });

// ── Build ──────────────────────────────────────────────────────────────────────
async function startBuild() {
  if (state.building) return;
  const p = state.project;
  if (!p.title || (!p.mainVideo && !(p.titles&&p.titles.length>0))) return;

  const BD25_BYTES = 23.3e9;
  const BD50_BYTES = 46.6e9;
  const allTitleFiles = [
    ...(p.mainVideo ? [{ path: p.mainVideo.path, size: p.mainVideo.size || 0, quality: p.mainVideo.videoQuality }] : []),
    ...(p.titles || []).map(t => ({ path: t.file?.path, size: t.file?.size || 0, quality: t.videoQuality })),
  ];
  let estBytes = 0;
  for (const { path: fp, size, quality } of allTitleFiles) estBytes += estimateTitleBytes(fp, size, quality);
  estBytes = Math.round(estBytes * 1.1);
  const estGb = (estBytes / 1e9).toFixed(1);
  if (estBytes > BD50_BYTES) {
    const ok = confirm(`⚠ Estimated disc size (~${estGb} GB) exceeds BD-50 capacity (46.6 GB).\n\nConsider splitting into multiple discs. Continue anyway?`);
    if (!ok) return;
  } else if (estBytes > BD25_BYTES && (p.discSize === 'BD-25' || !p.discSize)) {
    const ok = confirm(`⚠ Estimated disc size (~${estGb} GB) exceeds BD-25 capacity (23.3 GB).\n\nTip: Switch to BD-50 in Settings, or split into multiple discs. Continue anyway?`);
    if (!ok) return;
  }

  const additionalTitles = p.titles || [];
  const steps = [
    'Encoding video...',
    'Validating output',
    'Preparing main feature',
    'Generating menu...',
    'Building disc structure...',
    ...additionalTitles.map((t, i) => `Processing title ${i + 2}: ${(t.label || t.file?.name || 'Title').slice(0, 35)}`),
    ...(p.extras.length > 0 ? ['Processing special features'] : []),
    'Writing disc navigation...',
    'Assembling disc...',
    'Registering titles',
    'Finalising navigation',
    'Validating disc...',
    'Creating ISO...',
  ];
  state.buildStartTime = Date.now();
  state.buildEndTime = null;
  state.stepStartTimes = {};
  state.stepDetails = {};
  setState({ building:true, buildSteps:steps, buildCurrentStep:0, buildDone:false, buildError:null, builtIsoPath:null, ffmpegLog:'' });

  const includedEmbedded = (state.embeddedTracks||[]).filter(t => t.included !== false);
  const mainVideoPath = state.project.mainVideo?.path;
  const additionalTitlePaths = new Set((state.project.titles||[]).map(t => t.file?.path).filter(Boolean));
  const embeddedAudio = includedEmbedded.filter(t =>
    t.role === 'audio' && mainVideoPath && t.sourceFile === mainVideoPath
  );
  const embeddedSubs = includedEmbedded.filter(t =>
    t.role === 'subtitle' && (!t.sourceFile || !additionalTitlePaths.has(t.sourceFile))
  );
  const buildProject = {
    ...p,
    passThroughMode: false,
    forceTranscode: true,
    fastEncode: state.fastEncode,
    _diagEmbedded: (state.embeddedTracks||[]).map(t => ({ role: t.role, sourceFile: t.sourceFile, included: t.included !== false })),
    audioTracks: [
      ...(p.audioTracks||[]).filter(t => !t.excluded),
      ...embeddedAudio.map(t => ({ ...t, file: { path: t.sourceFile, name: t.sourceFileName }, embedded: true })),
    ],
    subtitleTracks: [
      ...(p.subtitleTracks||[]).filter(t => !t.excluded),
      ...embeddedSubs.map(t => ({ ...t, file: { path: t.sourceFile, name: t.sourceFileName }, embedded: true })),
    ],
  };
  const result = await window.discForge.buildDisc(buildProject);
  if (result.error) setState({ buildError: result.error });
}

async function startBuildFromDroppedFiles() {
  if (state.building) return;

  const active = state.droppedFiles.filter(f => resolvedFileType(f) !== 'Skip');
  if (!active.length) { alert('Add at least one video file to build a disc.'); return; }

  const title = state.project.title || (active[0]?.name.replace(/\.[^.]+$/, '').replace(/[._-]+/g, ' ').trim() || 'Disc');
  if (!state.project.title) setPrj({ title });

  const eType = effectiveDiscType();

  // Multi-title path
  if (eType === 'multi-title') {
    const eps = active.filter(f => resolvedFileType(f) === 'Episode');
    const targets = eps.length >= 2 ? eps : active;
    if (targets.length < 2) { alert('Multi-title requires at least 2 episode files.'); return; }
    await startMultiTitleBuildWithFiles(targets.map(f => ({ path: f.path, name: f.name })));
    return;
  }

  const episodes = active.filter(f => resolvedFileType(f) === 'Episode');
  const bonus    = active.filter(f => resolvedFileType(f) === 'Bonus Feature');
  const movieFile = active.find(f => resolvedFileType(f) === 'Movie');
  const quality  = state.globalQuality || 'crf20';

  const extras = bonus.map(f => ({
    id: uid(),
    name: f.name.replace(/\.[^.]+$/, '').replace(/[._-]+/g, ' ').trim(),
    type: 'Behind the Scenes',
    file: { path: f.path, name: f.name, size: f.size || 0 },
  }));

  // Single title (movie or 1 episode)
  if (eType === 'movie' || episodes.length < 2) {
    const mainFile = movieFile || episodes[0] || active[0];
    setPrj({
      mainVideo: { path: mainFile.path, name: mainFile.name, size: mainFile.size || 0, videoQuality: quality },
      extras,
      combinedEpisodes: null,
      chapters: [],
    });
    startBuild();
    return;
  }

  // Combine episodes path
  setState({ building: true, buildSteps: ['Combining episodes…'], buildCurrentStep: 0, buildDone: false, buildError: null, builtIsoPath: null, ffmpegLog: '' });

  const combineResult = await window.discForge.combineEpisodes({
    files: episodes.map(f => ({ path: f.path, name: f.name, size: f.size || 0 })),
    normalizeBeforeCombine: true,
  });

  if (combineResult.error) {
    setState({ buildError: combineResult.error, building: false });
    return;
  }

  setState({ building: false });

  const chapters = (combineResult.chapters || []).map(ch => ({ id: uid(), name: ch.name, time: ch.time, thumb: null }));
  const combinedFile = { path: combineResult.combinedPath, name: combineResult.combinedName, size: 0, videoQuality: quality };

  const probe = await window.discForge.probeFile(combineResult.combinedPath);
  if (probe.success && probe.data) {
    cacheProbeData(combineResult.combinedPath, probe.data);
    addEmbeddedTracksFromProbe(combineResult.combinedPath, combineResult.combinedName, probe.data);
  }

  setPrj({ mainVideo: combinedFile, combinedEpisodes: combineResult.episodes, chapters, extras });
  startBuild();
}

async function startMultiTitleBuildWithFiles(files) {
  const p = state.project;
  const outputDir = p.outputDir || (await window.discForge.getHomeDir()) + '/Desktop';
  const discName = p.title || 'Episodes';

  const steps = [
    ...files.flatMap((f, i) => [
      `Episode ${i+1}/${files.length}: encoding`,
      `Episode ${i+1}/${files.length}: mkvmerge`,
      `Episode ${i+1}/${files.length}: tsMuxeR`,
      `Episode ${i+1}/${files.length}: done`,
    ]),
    'Merging BDMV structures',
    'Patching navigation',
    'Validating disc structure',
    'Packaging ISO',
  ];

  window.discForge.removeAllListeners('build-progress');
  window.discForge.removeAllListeners('ffmpeg-progress');
  window.discForge.onBuildProgress(handleBuildProgress);
  window.discForge.onFFmpegProgress(line => {
    if (line.startsWith('__CRF_START:')) { state.crfTotalSecs = parseFloat(line.slice(12)) || 0; return; }
    const timeMatch  = line.match(/time=(\d{2}):(\d{2}):([\d.]+)/);
    const speedMatch = line.match(/speed=\s*([\d.]+)x/);
    if (state.crfTotalSecs > 0 && timeMatch) {
      const cur = parseInt(timeMatch[1])*3600 + parseInt(timeMatch[2])*60 + parseFloat(timeMatch[3]);
      const speed = speedMatch ? parseFloat(speedMatch[1]) : 0;
      const pct = Math.min(100, (cur/state.crfTotalSecs*100)).toFixed(0);
      let eta = '';
      if (speed > 0.01 && state.crfTotalSecs > cur) {
        const rem = Math.round((state.crfTotalSecs - cur) / speed);
        if (rem > 3) eta = ' — ~' + Math.floor(rem/60) + 'm ' + (rem%60) + 's left';
      }
      state.ffmpegLog = `CRF encode ${pct}%${eta}`;
    } else {
      if (!timeMatch) state.crfTotalSecs = 0;
      state.ffmpegLog = line;
    }
    const el = document.getElementById('ffmpeg-log');
    if (el) el.textContent = state.ffmpegLog;
    appendLog(line);
  });

  setState({ building: true, buildSteps: steps, buildCurrentStep: 0, buildDone: false, buildError: null, builtIsoPath: null, ffmpegLog: '' });
  const result = await window.discForge.buildMultiTitleDisc({ episodes: files, outputDir, discName, fastEncode: state.fastEncode });
  if (result.error) setState({ buildError: result.error });
}

function appendLog(msg) {
  const el = document.getElementById('build-log-panel');
  if (el) { el.textContent += msg + '\n'; el.scrollTop = el.scrollHeight; }
}

function handleBuildProgress(data) {
  if (data.done) {
    state.buildEndTime = Date.now();
    setState({ buildDone: true, builtIsoPath: data.isoPath, builtIsoSize: data.isoSize || 0 });
  } else if (data.step !== undefined) {
    const stepIdx = data.step;
    if (!state.stepStartTimes[stepIdx]) state.stepStartTimes = { ...state.stepStartTimes, [stepIdx]: Date.now() };
    if (data.detail !== undefined) state.stepDetails = { ...state.stepDetails, [stepIdx]: data.detail };
    setState({ buildCurrentStep: stepIdx });
  }
}

function closeBuildModal() {
  window.discForge.removeAllListeners('build-progress');
  window.discForge.removeAllListeners('ffmpeg-progress');
  window.discForge.onBuildProgress(handleBuildProgress);
  window.discForge.onFFmpegProgress(line => {
    state.ffmpegLog = line;
    const el = document.getElementById('ffmpeg-log');
    if (el) el.textContent = line;
  });
  state.buildEndTime = null;
  state.stepStartTimes = {};
  state.stepDetails = {};
  setState({ building: false, buildDone: false, buildError: null });
}

function revealISO() { if (state.builtIsoPath) window.discForge.revealInFinder(state.builtIsoPath); }

// ── Probe cache ────────────────────────────────────────────────────────────────
function cacheProbeData(filePath, data) {
  if (!data || !filePath) return;
  const vs = data.streams?.find(s => s.codec_type === 'video');
  const audioStreams = (data.streams || []).filter(s => s.codec_type === 'audio').map(s => ({ codec: s.codec_name || '', bitrate: parseInt(s.bit_rate || 0) }));
  const duration = parseFloat(data.format?.duration || 0);
  const videoBitrate = parseInt(vs?.bit_rate || data.format?.bit_rate || 0);
  state.probeCache = { ...state.probeCache, [filePath]: { duration, videoBitrate, audioStreams } };
}

const LOSSLESS_CODECS = ['flac','pcm_s24le','pcm_s16le','pcm_s32le','pcm_blu','truehd','mlp','dts-hd'];
function estimateTitleBytes(filePath, fileSize, videoQuality) {
  const mult = videoQualityMult(videoQuality);
  const cached = state.probeCache?.[filePath];
  if (!cached || !cached.duration) return (fileSize || 0) * 0.6 * mult;
  const dur = cached.duration;
  const videoBytes = (cached.videoBitrate || 0) * dur / 8;
  let audioBytes = 0;
  for (const as of (cached.audioStreams || [])) {
    const isLossless = LOSSLESS_CODECS.some(c => as.codec.toLowerCase().includes(c));
    audioBytes += (isLossless || !as.bitrate) ? 640000 * dur / 8 : as.bitrate * dur / 8;
  }
  if (!cached.audioStreams?.length) audioBytes = 640000 * dur / 8;
  return videoBytes * mult + audioBytes + 50e6;
}

// ── Project save / load ───────────────────────────────────────────────────────
async function saveProject() {
  const proj = {
    version: '1.7',
    title: state.project.title, description: state.project.description,
    discLabel: state.project.discLabel, resolution: state.project.resolution,
    videoFormat: state.project.videoFormat, outputDir: state.project.outputDir,
    discSize: state.project.discSize, combinedEpisodes: state.project.combinedEpisodes || null,
    mainVideo: state.project.mainVideo, titles: state.project.titles || [],
    audioTracks: state.project.audioTracks, subtitleTracks: state.project.subtitleTracks,
    chapters: state.project.chapters, extras: state.project.extras,
    menuConfig: state.project.menuConfig, embeddedTracks: state.embeddedTracks || [],
    droppedFiles: state.droppedFiles.map(f => ({ id: f.id, name: f.name, path: f.path, size: f.size, assignedType: f.assignedType, autoType: f.autoType })),
    discType: state.discType, globalQuality: state.globalQuality,
  };
  const savePath = await window.discForge.saveProjectFile(JSON.stringify(proj, null, 2));
  if (savePath) alert('Project saved to: ' + savePath);
}

async function loadProject() {
  const json = await window.discForge.loadProjectFile();
  if (!json) return;
  try {
    const proj = JSON.parse(json);
    state.embeddedTracks = proj.embeddedTracks || [];
    const loadedRes = RESOLUTIONS.find(r => r === proj.resolution) || RESOLUTIONS[0];
    const loadedFmt = VIDEO_FMTS.find(f => f === proj.videoFormat) || VIDEO_FMTS[0];
    setPrj({
      title: proj.title || '', description: proj.description || '',
      discLabel: proj.discLabel || '', resolution: loadedRes, videoFormat: loadedFmt,
      outputDir: proj.outputDir || '', discSize: proj.discSize || 'BD-25',
      combinedEpisodes: proj.combinedEpisodes || null, mainVideo: proj.mainVideo || null,
      titles: proj.titles || [], audioTracks: proj.audioTracks || [],
      subtitleTracks: proj.subtitleTracks || [], chapters: proj.chapters || [],
      extras: proj.extras || [], menuConfig: { ...state.project.menuConfig, ...(proj.menuConfig || {}) },
    });
    if (proj.droppedFiles?.length) {
      state.droppedFiles = proj.droppedFiles.map(f => ({ ...f, probeData: null, probing: false }));
    }
    if (proj.discType) state.discType = proj.discType;
    if (proj.globalQuality) state.globalQuality = proj.globalQuality;
    if (state.embeddedTracks.length === 0 && proj.mainVideo?.path) {
      const probe = await window.discForge.probeFile(proj.mainVideo.path);
      if (probe.success) addEmbeddedTracksFromProbe(proj.mainVideo.path, proj.mainVideo.name, probe.data);
    }
    render();
  } catch(e) { alert('Failed to load project: ' + e.message); }
}

// ── Render ─────────────────────────────────────────────────────────────────────
function render() {
  const scroller = document.querySelector('.content');
  const scrollTop = scroller ? scroller.scrollTop : 0;
  document.getElementById('app').innerHTML = buildHTML();
  attachListeners();
  if (scrollTop > 0) {
    const restored = document.querySelector('.content');
    if (restored) restored.scrollTop = scrollTop;
  }
  if (_focusedId) {
    const el = document.getElementById(_focusedId);
    if (el) {
      el.focus();
      if (_focusedPos !== null && el.setSelectionRange) {
        try { el.setSelectionRange(_focusedPos, _focusedPos); } catch(_) {}
      }
    }
    _focusedId = null; _focusedPos = null;
  }
}

// ── buildHTML ─────────────────────────────────────────────────────────────────
function buildHTML() {
  const { tools, building, buildDone, buildError } = state;

  if (building || buildDone || buildError) {
    return `
      ${titlebarHTML(tools)}
      <div class="layout" style="flex-direction:column">
        <div class="main">
          <div class="content" style="padding:0;display:flex;flex-direction:column">
            ${buildProgressHTML()}
          </div>
        </div>
      </div>
      ${state.burning ? burnModalHTML() : ''}
      ${state.showAbout ? aboutModalHTML() : ''}
    `;
  }

  return `
    ${titlebarHTML(tools)}
    <div class="layout" style="flex-direction:column">
      <div class="main">
        <div class="content">
          ${mainScreenHTML()}
        </div>
      </div>
    </div>
    ${state.settingsPanelOpen ? `
      <div id="settings-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:90;backdrop-filter:blur(2px)"></div>
      ${settingsPanelHTML()}
    ` : ''}
    ${state.burning ? burnModalHTML() : ''}
    ${state.showAbout ? aboutModalHTML() : ''}
  `;
}

// ── Titlebar ──────────────────────────────────────────────────────────────────
function titlebarHTML(tools) {
  const pill = (name, ok) => `<div class="tool-pill ${ok?'ok':'err'}"><div class="tool-dot ${ok?'ok':'err'}"></div>${name}</div>`;
  return `<div class="titlebar">
    <div style="width:72px;-webkit-app-region:no-drag"></div>
    <div class="titlebar-brand">
      <div class="titlebar-logo">💿</div>
      <span class="titlebar-name">Disc Forge</span>
      <span class="titlebar-version">1.7</span>
    </div>
    <div class="titlebar-spacer"></div>
    <div class="titlebar-tools">
      <button class="btn btn-ghost btn-sm" id="about-btn" style="font-size:12px;padding:4px 10px">About</button>
      <button class="btn btn-ghost btn-sm" id="save-project-btn" style="font-size:12px;padding:4px 10px">Save</button>
      <button class="btn btn-ghost btn-sm" id="load-project-btn" style="font-size:12px;padding:4px 10px">Load</button>
      ${pill('FFmpeg',   tools.ffmpeg?.found)}
      ${pill('tsMuxeR',  tools.tsmuxer?.found)}
      ${pill('mkvmerge', tools.mkvmerge?.found)}
      ${pill('xorriso',  tools.xorriso?.found)}
    </div>
  </div>`;
}

// ── Main screen ───────────────────────────────────────────────────────────────
function mainScreenHTML() {
  const files = state.droppedFiles;
  const hasFiles = files.length > 0;
  const allProbed = hasFiles && files.every(f => !f.probing);
  const anyProbing = files.some(f => f.probing);
  const canBuild = hasFiles && !anyProbing;

  return `
    <div style="max-width:720px;margin:0 auto;padding-bottom:140px">
      ${dropZoneHTML(hasFiles)}
      ${hasFiles ? fileListHTML() : ''}
      ${allProbed ? detectionSummaryHTML() : ''}
      ${allProbed && hasFiles ? discInfoHTML() : ''}
      ${!hasFiles ? emptyStateHintHTML() : ''}
    </div>
    <div style="position:sticky;bottom:0;left:0;right:0;padding:16px 32px 20px;background:linear-gradient(to bottom,transparent,var(--bg-base) 35%);pointer-events:none">
      <div style="max-width:720px;margin:0 auto;pointer-events:auto">
        ${buildFooterHTML(canBuild)}
      </div>
    </div>
    <style>@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}</style>
  `;
}

function emptyStateHintHTML() {
  return `
    <div style="text-align:center;padding:48px 0;opacity:0.5">
      <div style="font-size:14px;color:var(--text-tertiary);line-height:1.8">
        Drag files onto the drop zone or click it to browse<br>
        Supports MKV · MP4 · M2TS · TS · AVI · MOV
      </div>
    </div>
  `;
}

function dropZoneHTML(hasFiles) {
  const compact = !!hasFiles;
  return `
    <div id="main-drop-zone" class="drop-zone${compact ? ' has-file' : ''}"
      style="min-height:${compact ? '80px' : '200px'};margin-bottom:24px;cursor:pointer;transition:min-height 0.3s ease;border-style:dashed"
      ondragover="event.preventDefault();event.stopPropagation();this.style.borderColor='var(--gold)'"
      ondragleave="this.style.borderColor=''"
      ondrop="event.preventDefault();event.stopPropagation();this.style.borderColor='';window._handleFileDrop(event)">
      <div class="dz-icon" style="font-size:${compact ? '22px' : '36px'}">${compact ? '📂' : '💿'}</div>
      <div class="dz-text">
        <div class="dz-label${compact ? ' active' : ''}" style="font-size:${compact ? '13px' : '16px'}">
          ${compact
            ? `${state.droppedFiles.length} file${state.droppedFiles.length !== 1 ? 's' : ''} added — drop more or click to browse`
            : 'Drop video files here or click to browse'}
        </div>
        <div class="dz-hint">MKV · MP4 · M2TS · AVI · MOV · multiple files OK</div>
      </div>
    </div>
  `;
}

function fileListHTML() {
  const files = state.droppedFiles;
  return `
    <div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <div class="sidebar-label" style="margin-bottom:0">Files</div>
        <button class="btn btn-ghost btn-sm" id="clear-all-files" style="font-size:11px;color:var(--red);padding:3px 10px">Clear all</button>
      </div>
      ${files.map((f, i) => fileCardHTML(f, i)).join('')}
    </div>
  `;
}

function fileCardHTML(f, index) {
  const dur = f.probeData?.format?.duration;
  const durStr = dur ? `${Math.floor(dur / 60)}m ${Math.floor(dur % 60)}s` : null;
  const vs = f.probeData?.streams?.find(s => s.codec_type === 'video');
  const resStr = vs ? `${vs.width}×${vs.height}` : null;
  const type = resolvedFileType(f);
  const typeBadgeClass = { 'Episode': 'badge-blue', 'Bonus Feature': 'badge-purple', 'Movie': 'badge-gold', 'Skip': '' }[type] || 'badge-green';
  const typeBadge = f.probeData ? `<span class="badge ${typeBadgeClass}" style="font-size:10px;flex-shrink:0">${type}</span>` : '';

  return `
    <div class="track-card" style="margin-bottom:6px;padding:10px 14px;gap:10px">
      <span style="color:var(--text-tertiary);font-size:11px;font-family:var(--font-mono);min-width:16px;text-align:center">${index + 1}</span>
      <div style="font-size:16px;flex-shrink:0">${f.probing ? '<span style="display:inline-block;animation:spin 1s linear infinite">⏳</span>' : '🎬'}</div>
      <div class="track-body" style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(f.name)}</div>
        <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">
          ${f.probing ? '<span style="color:var(--gold-dim)">Probing…</span>' : [durStr, resStr].filter(Boolean).join(' · ') || 'Ready'}
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
        ${typeBadge}
        ${!f.probing ? `<select data-file-type="${f.id}" style="font-size:11px;padding:3px 22px 3px 7px;width:auto;height:26px;border-radius:5px">
          <option value="auto"${f.assignedType==='auto'?' selected':''}>Auto</option>
          <option value="Episode"${f.assignedType==='Episode'?' selected':''}>Episode</option>
          <option value="Bonus Feature"${f.assignedType==='Bonus Feature'?' selected':''}>Bonus</option>
          <option value="Movie"${f.assignedType==='Movie'?' selected':''}>Movie</option>
          <option value="Skip"${f.assignedType==='Skip'?' selected':''}>Skip</option>
        </select>` : ''}
        <button class="btn btn-danger" data-rm-dropped="${f.id}" style="padding:3px 8px;font-size:11px">✕</button>
      </div>
    </div>
  `;
}

function detectionSummaryHTML() {
  const active = state.droppedFiles.filter(f => resolvedFileType(f) !== 'Skip');
  if (!active.length) return '';

  const episodes = active.filter(f => resolvedFileType(f) === 'Episode');
  const bonus    = active.filter(f => resolvedFileType(f) === 'Bonus Feature');
  const movies   = active.filter(f => resolvedFileType(f) === 'Movie');
  const eType    = effectiveDiscType();

  const parts = [];
  if (movies.length)   parts.push(`${movies.length} Movie${movies.length !== 1 ? 's' : ''}`);
  if (episodes.length) parts.push(`${episodes.length} Episode${episodes.length !== 1 ? 's' : ''}`);
  if (bonus.length)    parts.push(`${bonus.length} Bonus Feature${bonus.length !== 1 ? 's' : ''}`);

  const modeDesc = eType === 'episodes'
    ? 'Episodes will be combined into one feature with chapter markers'
    : eType === 'multi-title'
    ? 'Each episode will be a separately selectable title (experimental)'
    : 'Single title disc — auto-plays on insert';

  return `
    <div style="background:var(--gold-glow);border:1px solid var(--border-gold);border-radius:var(--radius-lg);padding:14px 18px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
      <div style="font-size:22px;flex-shrink:0">✓</div>
      <div>
        <div style="font-size:14px;font-weight:700;color:var(--gold-bright);margin-bottom:3px">Detected: ${parts.join(' + ')}</div>
        <div style="font-size:12px;color:var(--text-secondary)">${modeDesc}</div>
      </div>
    </div>
  `;
}

function discInfoHTML() {
  const p = state.project;

  // Size estimate
  const active = state.droppedFiles.filter(f => resolvedFileType(f) !== 'Skip' && resolvedFileType(f) !== 'Bonus Feature');
  let estBytes = 0;
  for (const f of active) estBytes += estimateTitleBytes(f.path, f.size || 0, state.globalQuality);
  estBytes = Math.round(estBytes * 1.1);
  const estGb   = estBytes > 0 ? (estBytes / 1e9).toFixed(1) : null;
  const overBd25 = estBytes > 23.3e9;
  const overBd50 = estBytes > 46.6e9;
  const selectedSize = p.discSize || 'BD-25';

  return `
    <div class="card" style="margin-bottom:20px">
      <div class="card-header">
        <div class="card-icon">💾</div>
        <div><div class="card-title">Disc Info</div><div class="card-subtitle">Output settings for your disc image</div></div>
      </div>
      <div class="card-body">
        <div class="grid-2" style="margin-bottom:14px">
          <div class="field">
            <label class="field-label">Disc Title</label>
            <input type="text" id="disc-title-input" value="${esc(p.title)}" placeholder="Series or film name" />
          </div>
          <div class="field">
            <label class="field-label">Output Folder</label>
            <div style="display:flex;gap:8px;align-items:stretch">
              <div style="flex:1;font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:var(--bg-input);border:1px solid var(--border-mid);border-radius:var(--radius-md);padding:9px 12px">${esc(p.outputDir || '~/Desktop')}</div>
              <button class="btn btn-ghost btn-sm" id="pick-output-dir" style="white-space:nowrap;flex-shrink:0">Change</button>
            </div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
          ${estGb ? `<div style="font-size:12px;color:${overBd50 ? 'var(--red)' : overBd25 ? '#e67e22' : 'var(--text-secondary)'}">
            Estimated: <strong>${estGb} GB</strong>${overBd50 ? ' ⚠ Exceeds BD-50' : overBd25 ? ' ⚠ Exceeds BD-25' : ''}
          </div>` : ''}
          <div style="display:flex;align-items:center;gap:8px">
            <label class="field-label" style="margin-bottom:0">Disc size</label>
            <select id="disc-size-select" style="font-size:11px;padding:3px 22px 3px 8px;width:auto;height:28px">
              <option value="BD-25" ${selectedSize==='BD-25'?'selected':''}>BD-25 (25 GB)</option>
              <option value="BD-50" ${selectedSize==='BD-50'?'selected':''}>BD-50 (50 GB)</option>
            </select>
          </div>
          ${overBd25 && !overBd50 && selectedSize === 'BD-25' ? '<div style="font-size:11px;color:#e67e22">→ Switch to BD-50</div>' : ''}
        </div>
      </div>
    </div>
  `;
}

function buildFooterHTML(canBuild) {
  return `
    <div style="display:flex;align-items:center;gap:12px">
      <button id="open-settings-btn" style="background:var(--bg-overlay);border:1.5px solid var(--border-mid);color:var(--text-primary);font-size:12px;font-weight:600;padding:8px 16px;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;font-family:var(--font-ui);transition:all 0.15s" onmouseover="this.style.borderColor='var(--gold)';this.style.color='var(--gold)'" onmouseout="this.style.borderColor='var(--border-mid)';this.style.color='var(--text-primary)'">
        ⚙ Settings
      </button>
      <button class="btn-build" id="build-disc-btn" style="flex:1" ${!canBuild ? 'disabled' : ''}>
        <span class="btn-build-icon">🔨</span> Build Disc
      </button>
      ${state.builtIsoPath ? `<button class="btn" id="burn-btn" style="background:rgba(220,80,80,0.12);border:1px solid rgba(220,80,80,0.4);color:#e05050;padding:8px 16px;white-space:nowrap;font-size:13px">💿 Burn</button>` : ''}
    </div>
    ${!canBuild && state.droppedFiles.length === 0 ? '<div style="text-align:center;margin-top:8px;font-size:11px;color:var(--text-tertiary)">Drop video files above to get started</div>' : ''}
    ${!canBuild && state.droppedFiles.some(f => f.probing) ? '<div style="text-align:center;margin-top:8px;font-size:11px;color:var(--text-tertiary)">Probing files… please wait</div>' : ''}
  `;
}

// ── Settings panel ────────────────────────────────────────────────────────────
function settingsPanelHTML() {
  const p = state.project;
  const active = state.droppedFiles.filter(f => resolvedFileType(f) !== 'Skip');
  const eType = effectiveDiscType();
  const audioTracks = (state.embeddedTracks || []).filter(t => t.role === 'audio');
  const subTracks   = (state.embeddedTracks || []).filter(t => t.role === 'subtitle');

  const discTypeOptions = [
    { id: 'auto',        label: 'Auto-detect',    desc: `Currently: ${eType === 'movie' ? 'Movie disc' : eType === 'episodes' ? 'Episode disc (combined)' : 'Multi-title'}` },
    { id: 'movie',       label: 'Movie Disc',      desc: 'One main feature, auto-plays on insert' },
    { id: 'episodes',    label: 'Episode Disc',    desc: 'Combined with chapter markers — works on all players' },
    { id: 'multi-title', label: 'Multi-Title',     desc: 'Each episode selectable separately (experimental)' },
  ];

  return `
    <div id="settings-panel" style="position:fixed;right:0;top:0;bottom:0;width:440px;background:var(--bg-raised);border-left:1px solid var(--border-dim);overflow-y:auto;z-index:100;display:flex;flex-direction:column">

      <div style="padding:18px 24px;border-bottom:1px solid var(--border-dim);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:var(--bg-raised);z-index:10">
        <div style="font-size:15px;font-weight:700;color:var(--text-primary)">⚙ Settings</div>
        <button class="btn btn-ghost btn-sm" id="close-settings" style="font-size:12px">✕ Close</button>
      </div>

      <div style="padding:20px 24px;flex:1;display:flex;flex-direction:column;gap:28px">

        <!-- FILE ASSIGNMENTS -->
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">File Assignments</div>
          ${active.length ? active.map(f => `
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-dim)">
              <div style="flex:1;min-width:0;font-size:12px;font-weight:500;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name.replace(/\.[^.]+$/, ''))}</div>
              <select data-file-type="${f.id}" style="font-size:11px;padding:3px 22px 3px 7px;width:auto;height:26px;flex-shrink:0;border-radius:5px">
                <option value="auto"${f.assignedType==='auto'?' selected':''}>Auto</option>
                <option value="Episode"${f.assignedType==='Episode'?' selected':''}>Episode</option>
                <option value="Bonus Feature"${f.assignedType==='Bonus Feature'?' selected':''}>Bonus</option>
                <option value="Movie"${f.assignedType==='Movie'?' selected':''}>Movie</option>
                <option value="Skip"${f.assignedType==='Skip'?' selected':''}>Skip</option>
              </select>
            </div>
          `).join('') : '<div style="font-size:12px;color:var(--text-tertiary)">No files added yet</div>'}
        </div>

        <!-- DISC TYPE -->
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Disc Type</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${discTypeOptions.map(opt => `
              <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:var(--radius-md);border:1px solid ${state.discType===opt.id?'var(--border-gold)':'var(--border-dim)'};background:${state.discType===opt.id?'var(--gold-glow)':'transparent'};cursor:pointer" data-disc-type="${opt.id}">
                <input type="radio" name="disc-type" value="${opt.id}" ${state.discType===opt.id?'checked':''} style="margin-top:3px;accent-color:var(--gold);flex-shrink:0" />
                <div>
                  <div style="font-size:13px;font-weight:600;color:${state.discType===opt.id?'var(--gold-bright)':'var(--text-primary)'};margin-bottom:2px">${opt.label}</div>
                  <div style="font-size:11px;color:var(--text-tertiary)">${opt.desc}</div>
                </div>
              </div>
            `).join('')}
          </div>
          ${state.discType === 'multi-title' ? '<div style="margin-top:8px;padding:8px 12px;background:rgba(232,146,90,0.1);border:1px solid rgba(232,146,90,0.3);border-radius:6px;font-size:11px;color:#e8925a">⚠ Multi-title is experimental. Combined episodes work on all players.</div>' : ''}
        </div>

        <!-- VIDEO QUALITY -->
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Video Quality</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            ${VIDEO_QUALITY_MODES.map(m => {
              const sel = state.globalQuality === m.id;
              const icons = { crf18: '🔵', crf20: '🟢', crf23: '🟡' };
              const descs = { crf18: 'Larger file, best picture', crf20: 'Recommended', crf23: 'Smaller file, good picture' };
              return `<div style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:var(--radius-md);border:1px solid ${sel?'var(--border-gold)':'var(--border-dim)'};background:${sel?'var(--gold-glow)':'var(--bg-overlay)'};cursor:pointer" data-quality="${m.id}">
                <div style="font-size:18px;flex-shrink:0">${icons[m.id]}</div>
                <div style="flex:1">
                  <div style="font-size:13px;font-weight:600;color:${sel?'var(--gold-bright)':'var(--text-primary)'}">${m.label}</div>
                  <div style="font-size:11px;color:var(--text-tertiary)">${descs[m.id]}</div>
                </div>
                ${sel ? '<span class="badge badge-gold" style="font-size:10px;flex-shrink:0">Selected</span>' : ''}
              </div>`;
            }).join('')}
          </div>
          <div style="margin-top:8px;font-size:11px;color:var(--text-tertiary)">libx264 · AC3 640k audio</div>
          <div style="margin-top:12px;padding:10px 12px;border-radius:var(--radius-md);border:1px solid var(--border-dim);background:var(--bg-overlay)">
            <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer">
              <input type="checkbox" id="fast-encode-toggle" ${state.fastEncode ? 'checked' : ''} style="margin-top:2px;accent-color:var(--gold);flex-shrink:0" />
              <div>
                <div style="font-size:13px;font-weight:600;color:var(--text-primary)">⚡ Fast Encode (Experimental)</div>
                <div style="font-size:11px;color:var(--text-tertiary);margin-top:2px">Uses Apple Silicon hardware encoder. Faster but not recommended for final Blu-ray discs. May cause playback issues on hardware players.</div>
              </div>
            </label>
          </div>
        </div>

        <!-- AUDIO -->
        ${audioTracks.length ? `
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Audio Tracks</div>
          ${audioTracks.map(t => `
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-dim)">
              <input type="checkbox" ${t.included!==false?'checked':''} data-toggle-embedded="${t.id}" style="accent-color:var(--gold);flex-shrink:0" />
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:500;color:var(--text-primary)">${esc(t.label||t.language)}</div>
                <div style="font-size:10px;color:var(--text-tertiary)">${t.language} · ${t.codec}</div>
              </div>
              <span class="badge badge-blue" style="font-size:10px;flex-shrink:0">${t.language}</span>
            </div>
          `).join('')}
          <div style="margin-top:8px;font-size:11px;color:var(--text-tertiary)">All audio converted to AC3 640k for maximum player compatibility</div>
        </div>` : ''}

        <!-- SUBTITLES -->
        ${subTracks.length ? `
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Subtitles</div>
          ${subTracks.map(t => `
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border-dim)">
              <input type="checkbox" ${t.included!==false?'checked':''} data-toggle-embedded="${t.id}" style="accent-color:var(--gold);flex-shrink:0" />
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:500;color:var(--text-primary)">${esc(t.description||t.language)}</div>
                <div style="font-size:10px;color:var(--text-tertiary)">${t.language} · ${t.codec}${t.isForced?' · Forced':''}${t.isSDH?' · SDH':''}</div>
              </div>
              <span class="badge badge-purple" style="font-size:10px;flex-shrink:0">${t.language}</span>
            </div>
          `).join('')}
        </div>` : ''}

        <!-- STATIC BACKGROUND -->
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Static Background</div>
          <div style="font-size:11px;color:var(--text-tertiary);margin-bottom:10px">Optional background image shown on disc insert. The disc auto-plays the main feature.</div>
          ${p.menuConfig.backgroundImage ? `
            <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-overlay);border:1px solid var(--border-dim);border-radius:var(--radius-md);margin-bottom:8px">
              <div style="flex:1;font-size:11px;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.menuConfig.backgroundImage.split('/').pop())}</div>
              <button class="btn btn-ghost btn-sm" id="remove-bg-image" style="font-size:11px;color:#e05050;border-color:rgba(220,80,80,0.4);flex-shrink:0">Remove</button>
            </div>
          ` : ''}
          <button class="btn btn-ghost btn-sm" id="choose-bg-image" style="width:100%">Choose Background Image</button>
        </div>

        <!-- OUTPUT -->
        <div>
          <div class="sidebar-label" style="margin-bottom:10px">Output</div>
          <div class="field">
            <label class="field-label">Disc Title</label>
            <input type="text" id="settings-disc-title" value="${esc(p.title)}" placeholder="Series or film name" />
          </div>
          <div class="field">
            <label class="field-label">Disc Size</label>
            <select id="settings-disc-size">
              <option value="BD-25" ${(p.discSize||'BD-25')==='BD-25'?'selected':''}>BD-25 (25 GB)</option>
              <option value="BD-50" ${(p.discSize||'BD-25')==='BD-50'?'selected':''}>BD-50 (50 GB)</option>
            </select>
          </div>
          <div class="field">
            <label class="field-label">Output Folder</label>
            <div style="display:flex;gap:8px;align-items:stretch">
              <div style="flex:1;font-size:11px;color:var(--text-tertiary);font-family:var(--font-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:var(--bg-input);border:1px solid var(--border-mid);border-radius:var(--radius-md);padding:9px 12px">${esc(p.outputDir||'~/Desktop')}</div>
              <button class="btn btn-ghost btn-sm" id="settings-pick-output">Change</button>
            </div>
          </div>
        </div>

      </div>
    </div>
  `;
}

// ── Build progress (full-screen) ──────────────────────────────────────────────
function buildProgressHTML() {
  const { buildSteps:steps, buildCurrentStep:cur, buildDone, buildError, builtIsoPath, builtIsoSize, project:p } = state;
  const pct = steps.length ? Math.round((cur / steps.length) * 100) : 0;

  const now = Date.now();
  if (!state.buildStartTime && !buildDone && !buildError) state.buildStartTime = now;
  const endTs = state.buildEndTime || (buildDone ? now : null);
  const elapsed = state.buildStartTime ? Math.floor(((endTs || now) - state.buildStartTime) / 1000) : 0;
  function fmtSec(s) { return Math.floor(s/60) + 'm ' + (s%60) + 's'; }
  const elapsedStr = elapsed > 0 ? fmtSec(elapsed) : '';
  let etaStr = '';
  if (!buildDone && pct > 5 && pct < 100 && elapsed > 5) {
    const totalEst = Math.round(elapsed / (pct / 100));
    const remaining = Math.max(0, totalEst - elapsed);
    etaStr = remaining > 0 ? '~' + fmtSec(remaining) + ' remaining' : 'Almost done…';
  }

  const wrapper = (inner) => `
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 32px;min-height:400px">
      <div style="width:100%;max-width:560px">
        ${inner}
      </div>
    </div>
  `;

  // Error state
  if (buildError) {
    let friendlyError = buildError, hint = '';
    if (buildError.includes('ffmpeg') && buildError.includes('not found')) { friendlyError = 'FFmpeg is not installed or could not be found.'; hint = 'Install with: brew install ffmpeg'; }
    else if (buildError.includes('tsMuxeR') || buildError.includes('tsmuxer')) { friendlyError = 'tsMuxeR could not be found.'; hint = 'Download from github.com/justdan96/tsMuxeR'; }
    else if (buildError.includes('No such file') || buildError.includes('ENOENT')) { friendlyError = 'A required file could not be found.'; hint = 'Make sure your video files are still accessible.'; }
    else if (buildError.includes('Permission denied')) { friendlyError = 'Permission denied writing to the output folder.'; hint = 'Try changing the output folder to Desktop or Downloads.'; }
    else if (buildError.includes('No space left') || buildError.includes('ENOSPC')) { friendlyError = 'Not enough disk space to build the disc image.'; hint = 'Free up space and try again. BD-25 requires ~25 GB.'; }

    return wrapper(`
      <div style="text-align:center;margin-bottom:32px">
        <div style="font-size:48px;margin-bottom:16px">❌</div>
        <div style="font-size:22px;font-weight:700;color:var(--text-primary);margin-bottom:8px">Build Failed</div>
        <div style="font-size:14px;color:var(--red);margin-bottom:10px;font-weight:500">${esc(friendlyError)}</div>
        ${hint ? `<div style="font-size:12px;color:var(--text-secondary);background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:6px;padding:8px 14px;margin-bottom:12px">${esc(hint)}</div>` : ''}
        <details style="margin-bottom:16px;text-align:left">
          <summary style="font-size:11px;color:var(--text-tertiary);cursor:pointer;margin-bottom:6px">Show technical details</summary>
          <pre style="background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:6px;padding:10px;font-size:10px;color:var(--red);max-height:140px;overflow-y:auto;font-family:var(--font-mono);white-space:pre-wrap">${esc(buildError)}</pre>
        </details>
      </div>
      <button class="btn btn-primary" id="close-progress" style="width:100%;font-size:14px;padding:12px">← Back to Main Screen</button>
    `);
  }

  // Done state
  if (buildDone) {
    const isoSizeStr = builtIsoSize
      ? (builtIsoSize >= 1e9 ? (builtIsoSize/1e9).toFixed(2) + ' GB' : (builtIsoSize/1e6).toFixed(0) + ' MB')
      : null;
    const audioCount = p.audioTracks.length + (state.embeddedTracks||[]).filter(t=>t.role==='audio'&&t.included!==false).length;
    const subCount   = p.subtitleTracks.length + (state.embeddedTracks||[]).filter(t=>t.role==='subtitle'&&t.included!==false).length;
    return wrapper(`
      <div style="text-align:center;margin-bottom:32px">
        <div style="font-size:56px;margin-bottom:16px">✅</div>
        <div style="font-size:24px;font-weight:700;color:var(--gold-bright);margin-bottom:6px">Build Complete!</div>
        ${isoSizeStr ? `<div style="font-size:28px;font-weight:700;color:var(--text-primary);margin-bottom:4px">${isoSizeStr}</div>
        <div style="font-size:12px;color:var(--text-tertiary);margin-bottom:10px">ISO file size</div>` : ''}
        <div style="font-size:12px;color:var(--text-secondary);margin-bottom:6px">${audioCount} audio · ${subCount} subtitles · ${p.chapters.length} chapters · ${p.extras.length} extras</div>
        ${elapsedStr ? `<div style="font-size:11px;color:var(--text-tertiary);margin-bottom:10px">Completed in ${elapsedStr}</div>` : ''}
        <div style="font-size:11px;font-family:var(--font-mono);color:var(--text-tertiary);background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:6px;padding:8px 12px;word-break:break-all;margin-bottom:20px">${esc(builtIsoPath||'')}</div>
      </div>
      <div style="display:flex;gap:10px;flex-direction:column">
        <div style="display:flex;gap:10px">
          <button class="btn btn-ghost" id="reveal-iso" style="flex:1;font-size:13px;padding:10px">Show in Finder</button>
          <button class="btn btn-primary" id="burn-btn-done" style="flex:1;font-size:13px;padding:10px;background:rgba(220,80,80,0.2);border-color:rgba(220,80,80,0.5);color:#e05050">💿 Burn to Disc</button>
        </div>
        <button class="btn btn-ghost" id="close-progress" style="width:100%;font-size:13px;padding:10px">← Back to Main Screen</button>
      </div>
    `);
  }

  // In-progress state
  const stepsHTML = steps.map((s, i) => {
    const cls = i < cur ? 'done' : i === cur ? 'active' : 'wait';
    const detail = state.stepDetails[i] ? ` <span style="color:var(--text-tertiary);font-size:10px;margin-left:6px">— ${esc(state.stepDetails[i])}</span>` : '';
    return `<div class="build-step"><div class="step-indicator ${cls}">${i < cur ? '✓' : i + 1}</div><span class="step-text ${cls}">${s}${detail}</span></div>`;
  }).join('');

  return wrapper(`
    <div style="text-align:center;margin-bottom:28px">
      <div style="font-size:40px;margin-bottom:12px;animation:spin 3s linear infinite;display:inline-block">💿</div>
      <div style="font-size:20px;font-weight:700;color:var(--text-primary);margin-bottom:4px">Building Disc Image</div>
      <div style="font-size:13px;color:var(--text-secondary)"><strong>${esc(p.title||'Untitled')}</strong></div>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-tertiary);margin-bottom:6px">
      <span>${pct}% complete${elapsedStr ? ' · ' + elapsedStr + ' elapsed' : ''}</span>
      <span>${etaStr}</span>
    </div>
    <div class="progress-bar-wrap" style="margin-bottom:20px"><div class="progress-bar-fill" style="width:${pct}%;transition:width 0.5s ease"></div></div>
    <div class="build-steps" style="margin-bottom:16px">${stepsHTML}</div>
    <div style="margin-bottom:8px">
      <div id="ffmpeg-log" class="ffmpeg-log">${esc(state.ffmpegLog||'Starting…')}</div>
    </div>
    <details style="margin-top:8px">
      <summary style="font-size:11px;color:var(--text-tertiary);cursor:pointer">Show full log</summary>
      <div id="build-log-panel" style="background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:6px;padding:8px;font-size:10px;font-family:var(--font-mono);color:var(--text-tertiary);max-height:120px;overflow-y:auto;white-space:pre-wrap;margin-top:6px"></div>
    </details>
  `);
}

// ── Burn modal ─────────────────────────────────────────────────────────────────
function burnModalHTML() {
  const { burnStatus, burnMessage, burnDone, burnError, burnPercent, burnDriveInfo } = state;

  if (burnError) return `<div class="modal-backdrop"><div class="modal-box">
    <div class="modal-disc-icon" style="background:var(--red-dim);border-color:rgba(192,57,43,0.4)">❌</div>
    <div class="modal-title">Burn Failed</div>
    <pre style="background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:var(--radius-md);padding:12px;font-size:11px;color:var(--red);text-align:left;max-height:160px;overflow-y:auto;font-family:var(--font-mono);white-space:pre-wrap;margin-bottom:16px">${esc(burnError)}</pre>
    <div class="modal-actions"><button class="btn btn-ghost" id="close-burn-modal">Close</button></div>
  </div></div>`;

  if (burnDone) return `<div class="modal-backdrop"><div class="modal-box">
    <div class="modal-success-ring">💿</div>
    <div class="modal-title" style="color:var(--gold-bright)">Burn Complete!</div>
    <div class="modal-sub">Your disc has been burned and ejected.</div>
    <div class="modal-actions"><button class="btn btn-ghost" id="close-burn-modal">Done</button></div>
  </div></div>`;

  const drivePanel = burnDriveInfo ? (() => {
    const d = burnDriveInfo;
    const discOk = d.discStatus?.hasDisc;
    const driveName = d.drives?.[0]?.name || 'Optical Drive';
    const discLabel = discOk
      ? (d.discStatus.isBlank ? (d.discStatus.isBD ? 'Blank BD-R detected' : 'Blank disc detected') : 'Disc detected (check it is blank)')
      : 'No disc detected — insert a blank BD-R';
    return `<div style="background:var(--bg-sunken);border:1px solid var(--border-dim);border-radius:6px;padding:8px 12px;margin-bottom:12px;font-size:12px;color:var(--text-secondary)">
      <div style="font-weight:600;color:var(--text-primary);margin-bottom:4px">💿 ${esc(driveName)}</div>
      <div style="${discOk?'color:var(--green)':'color:var(--red)'}">${discLabel}</div>
      ${d.deviceNode ? `<div style="color:var(--text-tertiary);font-family:var(--font-mono);font-size:11px;margin-top:2px">${esc(d.deviceNode)}</div>` : ''}
    </div>`;
  })() : '';

  const pct = burnPercent != null ? burnPercent : (burnStatus==='done'?100:burnStatus==='burning'?30:5);
  const pctLabel = burnPercent != null ? Math.round(burnPercent) + '%' : '';

  return `<div class="modal-backdrop"><div class="modal-box">
    <div class="modal-disc-icon" style="animation:spin 2s linear infinite;display:inline-flex">💿</div>
    <div class="modal-title">Burning Disc</div>
    <div class="modal-sub">Do not eject the disc or close the app.</div>
    ${drivePanel}
    <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-tertiary);margin-bottom:4px">
      <span>${burnStatus==='starting'?'Preparing…':burnStatus==='burning'?'Writing…':'Finalizing…'}</span>
      <span>${pctLabel}</span>
    </div>
    <div class="progress-bar-wrap" style="margin-bottom:12px">
      <div class="progress-bar-fill" style="width:${pct}%;transition:width 0.5s ease"></div>
    </div>
    <div class="ffmpeg-log" style="text-align:left;max-height:80px;overflow-y:auto">${esc(burnMessage||'Preparing…')}</div>
  </div></div>`;
}

// ── About modal ────────────────────────────────────────────────────────────────
function aboutModalHTML() {
  const versions = [
    { v:'1.7', notes:['Settings button redesigned for better visibility','Static Background section in Settings: pick a background image shown on disc insert','Version bump'] },
    { v:'1.6', notes:['Redesigned UI: single-screen drop zone, auto-detection, settings panel','Auto-probe and classify dropped files (Movie / Episode / Bonus Feature)','Drag-and-drop support for multiple files','Detection summary card with build mode explanation','Settings panel: file assignments, disc type, video quality, audio/subtitle toggles'] },
    { v:'1.5.4', notes:['Auto BD-resolution correction — non-standard resolutions automatically padded or scaled to BD-compliant output'] },
    { v:'1.5.3', notes:['Blu-ray-safe output: libx264 H.264/AVC, AC3 640k, xorriso UDF 2.50 ISO — always'] },
    { v:'1.5.2', notes:['Video Quality Mode — per-title CRF selector: High Quality, Balanced, Compact','CRF encode progress with fps, frame count, and ETA'] },
    { v:'1.5', notes:['Disc burning, chapter thumbnails, enhanced menu customization, 6 new themes','Gradient background, background image effects, animated background'] },
    { v:'1.4', notes:['Full subtitle support, mkvmerge integration, track name metadata'] },
    { v:'1.0–1.3', notes:['Initial release through multi-title episode disc support'] },
  ];
  const vHTML = versions.map(ver => `
    <div style="margin-bottom:14px;text-align:left">
      <div style="font-size:12px;font-weight:700;color:var(--gold);margin-bottom:4px">v${ver.v}</div>
      ${ver.notes.map(n => `<div style="font-size:11px;color:var(--text-secondary);padding:1px 0 1px 10px">· ${n}</div>`).join('')}
    </div>
  `).join('');

  return `<div class="modal-backdrop"><div class="modal-box" style="max-width:440px">
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:40px;margin-bottom:6px">💿</div>
      <div class="modal-title" style="font-size:20px">Disc Forge</div>
      <div style="font-size:12px;color:var(--gold);font-weight:600;margin-bottom:4px">Version 1.7</div>
      <div style="font-size:11px;color:var(--text-tertiary)">Professional Blu-ray authoring for macOS</div>
    </div>
    <div style="max-height:320px;overflow-y:auto;border-top:1px solid var(--border-dim);border-bottom:1px solid var(--border-dim);padding:12px 0;margin-bottom:14px">
      <div style="font-size:10px;letter-spacing:.1em;color:var(--text-tertiary);margin-bottom:10px;text-align:center">VERSION HISTORY</div>
      ${vHTML}
    </div>
    <div style="font-size:11px;color:var(--text-tertiary);text-align:center;margin-bottom:6px">FFmpeg · tsMuxeR · xorriso</div>
    <div style="font-size:11px;color:var(--text-tertiary);text-align:center;margin-bottom:14px">Copyright © 2026 ETHM</div>
    <div class="modal-actions"><button class="btn btn-ghost" id="close-about">Close</button></div>
  </div></div>`;
}

// ── Listeners ──────────────────────────────────────────────────────────────────
function attachListeners() {
  // Global drop handler (set on window so ondrop attribute can call it)
  window._handleFileDrop = async (e) => {
    const files = Array.from(e.dataTransfer.files || []).map(f => ({
      path: f.path || f.name,  // Electron provides .path on File objects
      name: f.name,
      size: f.size || 0,
    })).filter(f => f.path);
    if (files.length) await handleDroppedFiles(files);
  };

  // Drop zone click → open files dialog
  document.getElementById('main-drop-zone')?.addEventListener('click', async () => {
    const files = await window.discForge.openFilesDialog({
      filters: [{ name: 'Video', extensions: ['mkv','mp4','ts','m2ts','avi','mov','wmv','vob','m4v','flv'] }],
    });
    if (files && files.length) await handleDroppedFiles(files);
  });

  // File type dropdowns (both in file list and settings panel)
  document.querySelectorAll('[data-file-type]').forEach(el => {
    el.addEventListener('change', () => {
      const id = el.dataset.fileType;
      state.droppedFiles = state.droppedFiles.map(f => f.id === id ? { ...f, assignedType: el.value } : f);
      autoClassifyDroppedFiles();
      render();
    });
  });

  // Remove individual file
  document.querySelectorAll('[data-rm-dropped]').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.dataset.rmDropped;
      const removed = state.droppedFiles.find(f => f.id === id);
      state.droppedFiles = state.droppedFiles.filter(f => f.id !== id);
      if (removed) {
        state.embeddedTracks = (state.embeddedTracks||[]).filter(t => t.sourceFile !== removed.path);
      }
      autoClassifyDroppedFiles();
      render();
    });
  });

  // Clear all files
  document.getElementById('clear-all-files')?.addEventListener('click', () => {
    if (!confirm('Remove all files?')) return;
    state.droppedFiles = [];
    state.embeddedTracks = [];
    setPrj({ mainVideo: null, combinedEpisodes: null, chapters: [], extras: [] });
  });

  // Disc title input (main screen)
  document.getElementById('disc-title-input')?.addEventListener('input', e => {
    _focusedId = 'disc-title-input'; _focusedPos = e.target.selectionStart;
    Object.assign(state, { project: { ...state.project, title: e.target.value } });
    render();
  });

  // Output folder (main screen)
  document.getElementById('pick-output-dir')?.addEventListener('click', pickOutputDir);

  // Disc size select (main screen)
  document.getElementById('disc-size-select')?.addEventListener('change', e => setPrj({ discSize: e.target.value }));

  // Build button
  document.getElementById('build-disc-btn')?.addEventListener('click', startBuildFromDroppedFiles);

  // Settings panel open/close
  document.getElementById('open-settings-btn')?.addEventListener('click', () => setState({ settingsPanelOpen: true }));
  document.getElementById('close-settings')?.addEventListener('click', () => setState({ settingsPanelOpen: false }));
  document.getElementById('settings-overlay')?.addEventListener('click', () => setState({ settingsPanelOpen: false }));

  // Disc type radio (settings panel)
  document.querySelectorAll('[data-disc-type]').forEach(el => {
    el.addEventListener('click', () => {
      state.discType = el.dataset.discType;
      render();
    });
  });

  // Quality cards (settings panel)
  document.querySelectorAll('[data-quality]').forEach(el => {
    el.addEventListener('click', () => {
      state.globalQuality = el.dataset.quality;
      render();
    });
  });

  // Fast encode toggle (settings panel)
  document.getElementById('fast-encode-toggle')?.addEventListener('change', e => {
    state.fastEncode = e.target.checked;
  });

  // Embedded track toggles (settings panel)
  document.querySelectorAll('[data-toggle-embedded]').forEach(el => {
    el.addEventListener('change', () => {
      const id = el.dataset.toggleEmbedded;
      state.embeddedTracks = state.embeddedTracks.map(t => t.id === id ? { ...t, included: el.checked } : t);
      render();
    });
  });

  // Settings panel fields
  document.getElementById('settings-disc-title')?.addEventListener('input', e => {
    _focusedId = 'settings-disc-title'; _focusedPos = e.target.selectionStart;
    Object.assign(state, { project: { ...state.project, title: e.target.value } });
    render();
  });
  document.getElementById('settings-disc-size')?.addEventListener('change', e => setPrj({ discSize: e.target.value }));
  document.getElementById('settings-pick-output')?.addEventListener('click', pickOutputDir);
  document.getElementById('choose-bg-image')?.addEventListener('click', async () => {
    const f = await pickFile([{ name: 'Images', extensions: ['png','jpg','jpeg','webp'] }]);
    if (f) { state.project.menuConfig.backgroundImage = f.path; render(); }
  });
  document.getElementById('remove-bg-image')?.addEventListener('click', () => {
    state.project.menuConfig.backgroundImage = null; render();
  });

  // Build progress controls
  document.getElementById('close-progress')?.addEventListener('click', closeBuildModal);
  document.getElementById('reveal-iso')?.addEventListener('click', revealISO);

  // Burn to disc (from done screen)
  document.getElementById('burn-btn-done')?.addEventListener('click', startBurn);
  document.getElementById('burn-btn')?.addEventListener('click', startBurn);

  // Burn modal close
  document.getElementById('close-burn-modal')?.addEventListener('click', () => {
    window.discForge.removeAllListeners('burn-progress');
    setState({ burning: false, burnDone: false, burnError: null, burnStatus: null, burnMessage: '' });
  });

  // Titlebar buttons
  document.getElementById('about-btn')?.addEventListener('click', () => setState({ showAbout: true }));
  document.getElementById('close-about')?.addEventListener('click', () => setState({ showAbout: false }));
  document.getElementById('save-project-btn')?.addEventListener('click', saveProject);
  document.getElementById('load-project-btn')?.addEventListener('click', loadProject);
}

async function startBurn() {
  if (!state.builtIsoPath) return;
  window.discForge.removeAllListeners('burn-progress');
  setState({ burning: true, burnStatus: 'checking', burnMessage: 'Detecting optical drives…', burnDone: false, burnError: null, burnPercent: 0, burnDriveInfo: null });
  try {
    const driveInfo = await window.discForge.detectDrives();
    setState({ burnDriveInfo: driveInfo, burnMessage: 'Drive detected — starting burn…' });
  } catch(_) {}
  window.discForge.onBurnProgress(data => {
    if (data.status === 'done') setState({ burnDone: true, burnStatus: 'done', burnMessage: data.message, burnPercent: 100 });
    else if (data.status === 'error') setState({ burning: true, burnError: data.message });
    else setState({ burnStatus: data.status, burnMessage: data.message, burnPercent: data.percent != null ? data.percent : state.burnPercent });
  });
  const result = await window.discForge.burnISO(state.builtIsoPath);
  if (result.error) setState({ burning: true, burnError: result.error });
}

// ── Start ──────────────────────────────────────────────────────────────────────
render();
boot();
